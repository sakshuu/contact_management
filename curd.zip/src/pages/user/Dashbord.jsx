import React from 'react'

export default function Dashbord() {
  return (
    <div>Dashbord</div>
  )
}
